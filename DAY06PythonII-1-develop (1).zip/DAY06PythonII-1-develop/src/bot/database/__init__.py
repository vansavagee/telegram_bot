from src.bot.database.dbapi import DatabaseConnector


def Database(dbname, user, password, host, port):
    db = DatabaseConnector(dbname, user, password, host, port)
    return db

def Session(db):
    return db.connection()