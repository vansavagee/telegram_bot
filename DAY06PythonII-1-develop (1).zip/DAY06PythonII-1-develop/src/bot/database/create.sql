--Создание БД
CREATE DATABASE bot
--Создание таблиц
CREATE TABLE Books(
	book_id SERIAL PRIMARY KEY NOT NULL,
	title CHARACTER VARYING(100) NOT NULL,
	author CHARACTER VARYING(100) NOT NULL,
	published INTEGER NOT NULL,
	date_added DATE NOT NULL,
	date_deleted DATE
)

CREATE TABLE Borrows(
	borrow_id SERIAL PRIMARY KEY NOT NULL,
	book_id INTEGER REFERENCES Books(book_id),
	date_start TIMESTAMP NOT NULL,
	date_end TIMESTAMP,
	user_id INTEGER
)