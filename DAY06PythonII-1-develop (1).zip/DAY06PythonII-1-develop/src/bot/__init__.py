from src.bot.database import Database

db = Database('bot', 'beaujuli', '', 'localhost','5440')